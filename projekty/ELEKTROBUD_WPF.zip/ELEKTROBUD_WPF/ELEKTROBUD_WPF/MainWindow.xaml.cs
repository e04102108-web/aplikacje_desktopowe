﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ELEKTROBUD_WPF
{
	public partial class MainWindow : Window
	{

		private ObservableCollection<Przyjecie> historia = new ObservableCollection<Przyjecie>(); // lista towaru

		public MainWindow()
		{
			InitializeComponent(); // uruchamia okno
			HistoriaDataGrid.ItemsSource = historia; // pokazuje liste
		}

		private void PrzyjmijTowar_Click(object sender, RoutedEventArgs e)
		{
			string kod = EanTextBox.Text.Trim(); // pobieramy
			string nazwa = ProduktTextBox.Text.Trim(); 
			string osoba = PracownikTextBox.Text.Trim(); 
			int sztuki;

			if (kod == "" || nazwa == "" || osoba == "") // sprawdza pola
			{
				MessageBox.Show("Wypelnij wszystkie pola.", "Brak danych", MessageBoxButton.OK, MessageBoxImage.Warning);
				return;
			}

			if (!CzyPoprawnyEAN(kod)) 
			{
				MessageBox.Show("Kod EAN musi mieć 8, 13 lub 14 cyfr.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Warning);
				return;
			}

			if (!int.TryParse(IloscTextBox.Text, out sztuki) || sztuki <= 0) // sprawdza ilosc
			{
				MessageBox.Show("Podaj dobra ilość.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Warning);
				return;
			}

			Przyjecie nowe = new Przyjecie 
			{
				EAN = kod,
				Produkt = nazwa,
				Ilosc = sztuki,
				Pracownik = osoba,
				Data = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss")
			};

			historia.Add(nowe); // + do tabeli

			MessageBox.Show("Przyjecie towaru zapisane.", "Elektro-Bud", MessageBoxButton.OK, MessageBoxImage.Information);

			EanTextBox.Clear(); 
			ProduktTextBox.Clear();
			IloscTextBox.Clear();
			EanTextBox.Focus(); // wraca do kodu
		}

		private bool CzyPoprawnyEAN(string kod) 
		{
			if (kod.Length != 8 && kod.Length != 13 && kod.Length != 14)
			{
				return false; 
			}

			foreach (char znak in kod) // sprawdza kazdy znak
			{
				if (!char.IsDigit(znak))
				{
					return false; 
				}
			}

			return true;
		}

		private void PracownikTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			//ruchomi się gdy zmienie tekst w polu pracownika
		}

	}

	public class Przyjecie // dane przyjecia
	{
		public string EAN { get; set; }
		public string Produkt { get; set; }
		public int Ilosc { get; set; }
		public string Pracownik { get; set; }
		public string Data { get; set; }
	}

}

	